# Constraint: signal-type

## Intent fragment

Recognize Angular **signal-based** construction or typing on a class **property** (`PropertyDeclaration`). Compose with **property** and **reactive-property** when the user asks about signals specifically (or when you need to exclude / include the signal bucket precisely).

**Prefer the initializer**, then the type annotation.

## Heuristics (planning)

- **Call to `signal`** — initializer is (or wraps) a call expression whose callee resolves to the **`signal`** factory (typically imported from `@angular/core`).
- **`Signal` typing** — type annotation or dominant type uses identifier **`Signal`**, **`WritableSignal`**, **`InputSignal`**, **`ModelSignal`**, or similar Angular signal-related type names, with imports whose module specifier contains **`@angular/core`** when you resolve them.
- **Generic `Signal<…>`** — type arguments often carry the carried value type; still counts as signal-oriented for branching.

## Negative check

If none of the above apply on that property, it is **not** in the signal bucket for this constraint (it may still match observable-type or be normal — **Search for `[observable-type]`** and **Search for `[reactive-property]`** via `search_constraint_context`).

## Related constraints (backend-safe)

- **Search for `[observable-type]`** — `search_constraint_context({ constraintKeywords: ["observable-type"] })`
- **Search for `[reactive-property]`** — `search_constraint_context({ constraintKeywords: ["reactive-property"] })`
