# Pattern: signal-property

## Intent

Find all signal properties.

A signal property means:

- `ClassDeclaration`
  - has member `PropertyDeclaration`
    - whose type resolves to `Signal` imported from `@angular/core`
